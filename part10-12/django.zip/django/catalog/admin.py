from django.contrib import admin
from .models import Director, Film, FilmInstance, Genre

admin.site.register(Director)
admin.site.register(Film)
admin.site.register(FilmInstance)
admin.site.register(Genre)